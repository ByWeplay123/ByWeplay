##########
# Graves #
##########
The ULTIMATE full featured lightweight death chest plugin / player grave plugin!
Every feature you could ever need and more! While still being lightweight and efficient.

##########
# Config #
##########
Configuration is done in the config folder, all .yml files are read on startup and merged into one file for the
plugin to read, this is done to make the config files easier read and understand.
The main configuration settings for Graves is in config/grave.yml

###########
# Support #
###########
If you are having an issue with the plugin, and need help because something is not working as expected, you can't understand
something in the config files, or you are getting unexpected results. You can join our Discord for help.
Discord: https://discord.ranull.com/

##########
# Review #
##########
If this plugin has been useful to you, reviewing on Spigot helps a lot! :)
https://www.spigotmc.org/resources/graves.74208/
